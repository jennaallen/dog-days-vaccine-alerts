[![Build Status](https://travis-ci.org/jennaallen/dog-days-vaccine-alerts.svg?branch=master)](https://travis-ci.org/jennaallen/dog-days-vaccine-alerts)

# dog-days-vaccine-alerts
This is a project to setup automatic alerts when the dogs are due for vaccines.